---
language:
  - en
pretty_name: "Company Reports Dataset"
tags:
  - esg reports
  - sustainability
  - corporate governance
  - environmental
license: "cc-by-sa-4.0"
task_categories:
  - text-classification
configs:
  - config_name: default
    data_files:
      - split: "2024_02_03"
        path:
          - "data/company_reports_2024_02_03.json"
      - split: "2024_01_23"
        path:
          - "data/company_reports_2024_01_23.json"
      - split: "2024_01_22"
        path:
          - "data/company_reports_2024_01_22.json"
      - split: "2024_01_21"
        path:
          - "data/company_reports_2024_01_21.json"
      - split: "2024_01_19"
        path:
          - "data/company_reports_2024_01_19.json"
---

# Company Reports Dataset

## Description

This dataset contains ESG (Environmental, Social, and Governance) sustainability reports from various companies. It includes data like company details, report categories, textual analysis of the reports, and more.

## Dataset Structure

- `id`: Unique identifier for each report entry.
- `document_category`: Classification of the document (e.g., ESG sustainability report).
- `year`: Publication year of the report.
- `company_name`: Name of the respective company.
- `company_description`: A concise description of the company.
- `company_website`: The official website URL of the company.
- `economic_activity`: Sector of economic activity.
- `file_name`: Filename of the report.
- `url`: Direct URL to access the report.
- `downloaded_at`: Date and time when the report was downloaded.
- `text_analyzed`: The analyzed text extracted from the report.
- `tot_text_cleaned`: The cleaned version of the report text.
- `tot_text_raw`: The original, unedited text of the report.
- `documents_description`: A short description of the documents.

## Data Processing Versions

Different versions of the dataset are available, each processed with specific methodologies:

### Version: 2024_01_19

- **Extraction Methodology**: Utilizing 'unstructured' package with the following parameters:
  - Partition method with strategy = fast
- **Translation Methodology**:
  - Individual element_id translation using the multilingual model 'facebook/m2m100_418M'
- **Feature Extraction Methodology**:
  - Concatenation of cleaned and translated element_ids, with GPT-3.5-turbo model applied to the first 2500 characters for JSON extraction.

### Versions: 2024_01_21, 2024_01_22

- **Extraction Methodology**: Employing 'unstructured' package with the following parameters:
  - Partition_pdf method with strategy = auto
- **Translation Methodology**:
  - Aggregating into chunks, translating each chunk using Helsinki-NLP/opus-mt-{source_lang}-{target_lang} models. Language detection on each chunk is performed using langdetect.detect(text_cleaned[:100]).
- **Feature Extraction Methodology**:
  - Concatenation of cleaned and translated chunks, with GPT-3.5-turbo model applied to the first 2500 characters for JSON extraction.

### Version: 2024_01_23

- [Details to be updated]

## Collection Methodology

The dataset was collected from publicly available ESG reports of various companies to represent a wide range of industries.

## Intended Use

This dataset is suitable for tasks like text analysis, ESG metric analysis, corporate sustainability practice research, and more.

## Useful link

https://huggingface.co/docs/datasets/share

## Licensing

The dataset is available under the [CC-BY-SA-4.0](https://creativecommons.org
/licenses/by-sa/4.0/) license. Please ensure to adhere to the terms of this license when using or distributing this dataset.
